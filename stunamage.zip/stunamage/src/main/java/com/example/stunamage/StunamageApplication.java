package com.example.stunamage;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(value = "com.example.stunamage.mapper")
public class StunamageApplication {

    public static void main(String[] args) {
        SpringApplication.run(StunamageApplication.class, args);
    }

}
