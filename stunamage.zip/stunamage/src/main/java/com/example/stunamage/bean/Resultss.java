package com.example.stunamage.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
public class Resultss {
    private int resId;
    private String stuId;
    private String subName;


    private int    resNum;
    private String resTerm;

    public Resultss() {
    }

    public Resultss(int resId, String stuId, String subName, int resNum, String resTerm) {
        this.resId = resId;
        this.stuId = stuId;
        this.subName = subName;
        this.resNum = resNum;
        this.resTerm = resTerm;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    public int getResNum() {
        return resNum;
    }

    public void setResNum(int resNum) {
        this.resNum = resNum;
    }

    public String getResTerm() {
        return resTerm;
    }

    public void setResTerm(String resTerm) {
        this.resTerm = resTerm;
    }

}
