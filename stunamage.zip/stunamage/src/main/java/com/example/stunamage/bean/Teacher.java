package com.example.stunamage.bean;

import javax.validation.constraints.Size;


public class Teacher {
    private String teaId;
    private String teaName;
    private String teaPass;
    private String teaSex;
    private String teaTele;

    public Teacher() {
    }

    public Teacher(String teaId, String teaName, String teaPass, String teaSex, String teaTele) {
        this.teaId = teaId;
        this.teaName = teaName;
        this.teaPass = teaPass;
        this.teaSex = teaSex;
        this.teaTele = teaTele;
    }

    public String getTeaId() {
        return teaId;
    }

    public void setTeaId(String teaId) {
        this.teaId = teaId;
    }

    public String getTeaName() {
        return teaName;
    }

    public void setTeaName(String teaName) {
        this.teaName = teaName;
    }

    public String getTeaPass() {
        return teaPass;
    }

    public void setTeaPass(String teaPass) {
        this.teaPass = teaPass;
    }

    public String getTeaSex() {
        return teaSex;
    }

    public void setTeaSex(String teaSex) {
        this.teaSex = teaSex;
    }

    public String getTeaTele() {
        return teaTele;
    }

    public void setTeaTele(String teaTele) {
        this.teaTele = teaTele;
    }

}
