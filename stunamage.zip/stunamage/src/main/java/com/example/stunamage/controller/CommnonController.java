package com.example.stunamage.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class CommnonController {

    @RequestMapping("/logout")
    public String logout()
    {

        return "redirect:/index.html";
    }

}