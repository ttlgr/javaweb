package com.example.stunamage.service;

import com.example.stunamage.bean.Admin;
import com.example.stunamage.mapper.AdminMapper;


public interface AdminService  {
    Admin adminLogin(String AdminId,String AdminPass);
}
