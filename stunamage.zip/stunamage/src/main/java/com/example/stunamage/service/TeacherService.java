package com.example.stunamage.service;

import com.example.stunamage.bean.Student;
import com.example.stunamage.bean.Teacher;

import java.util.List;


public interface TeacherService {

    Teacher login(String teaId, String teaPass);

    List<Teacher> getAllTeacher();

    int addTeacher(Teacher teacher);

    int addTeacherHavePass(Teacher teacher);

    Teacher selectById(String teaId);

    int deleTea(String teaId);
}
